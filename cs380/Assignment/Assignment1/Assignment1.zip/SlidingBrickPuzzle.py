def swapIdx(state,idx1,idx2):
	for i in range(0,len(state)):
		for j in range(0,len(state[i])):
			if state[i][j] == idx1:
				state[i][j] = idx2
			elif state[i][j] == idx2:
				state[i][j] = idx2

def getBlockSide(state,piece):
	pos = []
	for i in range(0,len(state)):
		for j in range(0,len(state[i])):
			if int(state[i][j]) == int(piece):
				pos.append([i,j])

	# If the piece is not present, return empty list
	if len(pos) == 0:
		return []

	# Check the side of the piece
	vertical = []
	horizontal = []
	for item in pos:
		if item[0] not in horizontal: horizontal.append(item[0])
		if item[1] not in vertical: vertical.append(item[1])
	vertical.sort()
	horizontal.sort()

	return [vertical,horizontal]

class SlidingBrickPuzzle(object):
	def __init__(self):
		self.filename = None
		self.current_state = []
		self.original_state = []
		self.height = 0
		self.width = 0

	def loadGameStateFromDisk(self,filename):
		state = []
		try:
			f = open(filename,"r")
			first_line = f.readline().split(",")
			self.width = first_line[0]
			self.height = first_line[1]	
			for line in f:
				item = line.split(",")
				item = [x for x in item if x != "\n" and x != ""]
				state.append(item)
			self.filename = filename
			self.original_state = state 
			self.current_state = state
		except Exception as exception:
			print "Load game state from disk exception" + exception

	def displayGameState(self,state=None):
		if state == None:
			state = self.current_state
		print self.width + "," + self.height + ","
		for row in self.current_state:
			s = ""
			for item in row:
				s += str(item) + ","
			print s

	def cloneState(self,state=None):
		if state == None:
			state = self.current_state
		output = []
		for row in state:
			o = []
			for item in row:
				o.append(item)
			output.append(o)
		return output

	def isSolved(self):
		try:
			if len(self.current_state) == 0:
				return False
			for row in self.current_state:
				for item in row:
					if int(item) == -1:
						return False
			return True
		except Exception as exception:
			print "Checking puzzle exception " + exception 
		return False

	def allPossibleMoveOfPiece(self,piece):
		# Return empty list if the piece is not correct
		if int(piece) < 2:
			return []

		blockSide = getBlockSide(self.current_state,piece)
		vertical = blockSide[0]
		horizontal = blockSide[1]

		output = ["UP","DOWN","RIGHT","LEFT"]
		
		# Check UP move
		up_pos = horizontal[0] - 1
		for piece_pos in vertical:
			if int(self.current_state[up_pos][piece_pos]) != 0:
				output.remove('UP')
				break
	
		# Check DOWN move
		down_pos = horizontal[len(horizontal)-1] + 1
		for piece_pos in vertical:
			if int(self.current_state[down_pos][piece_pos]) != 0:
				output.remove('DOWN')
				break

		# Check LEFT move
		left_pos = vertical[0] - 1
		for piece_pos in horizontal:
			if int(self.current_state[piece_pos][left_pos]) != 0:
				output.remove('LEFT')
				break

		# Check RIGHT move
		right_pos = vertical[len(vertical)-1] + 1
		for piece_pos in horizontal:
			if int(self.current_state[piece_pos][right_pos]) != 0:
				output.remove('RIGHT')
				break

		return output
		
	def allPossibleMoveOfBoard(self):
		piece = {}
		for row in self.current_state:
			for item in row:
				if item not in piece and int(item) > 1:
					piece[item] = None
		
		for key in piece:
			piece[key] = self.allPossibleMoveOfPiece(key)
		
		return piece


	def applyMove(self,state,piece,direction):
		possibleMove = self.allPossibleMoveOfPiece(piece)
		if direction not in possibleMove:
			return
		else:
			blockSide = getBlockSide(state,piece)
			vertical = blockSide[0]
			horizontal = blockSide[1]
			if direction == "UP":
				new_empty_pos = horizontal[len(horizontal)-1]
				for i in range(0,len(horizontal)): 
					horizontal[i] -= 1
				for i in horizontal:
					for j in vertical:
						state[i][j] = piece
						state[new_empty_pos][j] = 0
			elif direction == "DOWN":
				new_empty_pos = horizontal[0]
				for i in range(0,len(horizontal)): 
					horizontal[i] += 1
				for i in horizontal:
					for j in vertical:
						state[i][j] = piece
						state[new_empty_pos][j] = 0
			elif direction == "LEFT":
				new_empty_pos = vertical[len(vertical)-1]
				for i in range(0,len(vertical)): 
					vertical[i] -= 1
				for i in horizontal:
					for j in vertical:
						state[i][j] = piece
						state[i][new_empty_pos] = 0
			else:
				new_empty_pos = vertical[0]
				for i in range(0,len(vertical)): 
					vertical[i] += 1
				for i in horizontal:
					for j in vertical:
						state[i][j] = piece
						state[i][new_empty_pos] = 0

	def applyMoveCloning(self,piece,direction):
		new_state = self.cloneState()
		self.applyMove(new_state,piece,direction)
		return new_state

	def isComparison(self,compare_state):
		state1 = self.current_state
		state2 = compare_state
		try:
			if len(state1) != len(state2):
				return False
			for i in range(0,len(state1)):
				if len(state1[i]) != len(state2[i]):
					return False
				for j in range(0,len(state1[i])):
					if state1[i][j] != state2[i][j]:
						return False
			return True
		except Exception as exception: 
			print "Compare state exception" + exception
		return False

	def normalizeState(self):
		nextIdx = 3
		for i in range(0,len(self.current_state)):
			for j in range(0,len(self.current_state[i])):
				if self.current_state[i][j] == nextIdx:
					nextIdx += 1
				elif self.current_state[i][j] > nextIdx:
					swapIdx(self.current_state,nextIdx,self.current_state[i][j])
					nextIdx += 1


# Load game and display game state
a = SlidingBrickPuzzle()
print "------Load Game and Display Game State--------"
a.loadGameStateFromDisk("SBP-level0.txt")
print "Game State: "
a.displayGameState()
print "----------------------------------------------"

print "\n\n"

print "-------Check Puzzle Solved---------"
a.loadGameStateFromDisk("SBP-level0-true.txt")
print "Game State: "
a.displayGameState()
print "Solve: " + str(a.isSolved())
print "-----------------------------------"

#print a.allPossibleMoveOfPiece(3)

print "\n\n"

print "-------Check Comparison State--------"
print "State 1: "
a.loadGameStateFromDisk("SBP-level0.txt")
a.displayGameState()
b = SlidingBrickPuzzle()
b.loadGameStateFromDisk("SBP-level0.txt")
print 
print "State 2: "
print b.displayGameState()
print "Is Identical: " + str(a.isComparison(b.current_state))
print "-------------------------------------"

print "\n\n"

print "-------All Possible Move----------"
c = SlidingBrickPuzzle()
print "Game State:"
c.loadGameStateFromDisk("SBP-level3.txt")
c.displayGameState()
print "\nPossible move of piece 6: "
print c.allPossibleMoveOfPiece(6)
print "\nAll possible move of board: "
print c.allPossibleMoveOfBoard()
print "-------------------------------------------"

print "\n\n"

print "--------Apply Move---------"
print "Game State: "
c.displayGameState()
print "\nApply Move of Piece 8 Direction UP: "
c.applyMove(c.current_state,8,"UP")
c.displayGameState()
print "\nApply Move of Piece 8 Direction DOWN: "
c.applyMove(c.current_state,8,"DOWN")
c.displayGameState()
print "\nApply Move of Piece 9 Direction LEFT: "
c.applyMove(c.current_state,9,"LEFT")
c.displayGameState()
print "\nApply Move of Piece 9 Direction RIGHT: "
c.applyMove(c.current_state,9,"RIGHT")
c.displayGameState()
print "---------------------------"